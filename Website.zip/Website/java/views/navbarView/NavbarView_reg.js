import * as User from "../../models/UserModel.js";

function navbarView() {
  User.init();

  // CONSTRUIR CONTEÚDO DA NAVBAR (VERIFICAR SE USER AUTENTICADO)
  let result = `
  <div class="container-fluid ">
    <button class="navbar-toggler" type="button" data-mdb-toggle="collapse" data-mdb-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <i class="fas fa-bars"></i>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <a class="navbar-brand mt-2 mt-lg-0" href="../index.html">
        <img
          src="../img/logotipo final IDA.png"
          height="45"
          alt="MDB Logo"
          loading="lazy"
        />
      </a>
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="../Prototipagem/jogo/index.html">Jogar</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Tabela de classificação</a>
        </li>
      </ul>
    </div>
  `;

  if (User.isLogged()) {
    result += `<div class="dropdown">
    <img
      src="https://mdbcdn.b-cdn.net/img/new/avatars/2.webp"
      class="rounded-circle"
      height="25"
      alt="Black and White Portrait of a Man"
      loading="lazy"
    />
  </a>
</div>
                `;
  } else {
    result += `                   
    <div class="d-flex align-items-center">      
    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      <li class="nav-item">
          <a class="nav-link" href="Registar.html">Registar</a>
        </li>
    </ul>
                `;
  }
  result += `</div>
</div>
`;

  // INJETAR CONTEÚDO NA NAVBAR
  document.querySelector("nav").innerHTML = result;

  // CLICAR NO BOTÃO DE REGISTAR
  document.getElementById("RegisterFrm")?.addEventListener("submit", (event) => {
      event.preventDefault();
      // Gestão do formulário de Registo
      const registerUsername = document.getElementById("txtUsernameRegister");
      const registerPassword = document.getElementById("txtPasswordRegister");
      const registerPassword2 = document.getElementById("txtPasswordRegister2");
      try {
        if (registerPassword.value !== registerPassword2.value) {
          throw Error("Password and Confirm Password are not equal");
          
        }
        User.add(registerUsername.value, registerPassword.value);
        displayMessage(
          "msgRegister",
          "User registered with success!",
          "success"
        );
        // Wait 1 second before reloading, so the user can see the login success messag
      } catch (e) {
        displayMessage("msgRegister", e.message, "danger");
      }
    });

  // CLICAR NO BOTÃO DE LOGIN
  document.getElementById("Loginfrm")?.addEventListener("submit", (event) => {
    event.preventDefault();
    try {
      User.login(
        document.getElementById("txtUsername").value,
        document.getElementById("txtPassword").value
      );
      displayMessage("msgLogin", "User logged in with success!", "success");
      // Wait 1 second before reloading, so the user can see the login success message
    } catch (e) {
      displayMessage("msgLogin", e.message, "danger");
    }
  });

  // CLICAR NO BOTÃO LOGOUT (O BOTÃO PODE NÃO EXISTIR POR ISSO USAR "?"" - OPTIONAL CHAINING)
  document.querySelector("#btnLogout")?.addEventListener("click", () => {
    User.logout();
    location.reload();
  });
}

function displayMessage(modal, message, type) {
  alert("entraste")
  setTimeout(() => {
    divMessage.innerHTML = "";
  }, 2000);
}

navbarView();
